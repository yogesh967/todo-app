import { combineReducers } from "redux";

export default combineReducers({
  //   authReduser,
  //   paymentReducer,
  //   recipientReducer,
});
